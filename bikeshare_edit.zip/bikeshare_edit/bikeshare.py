# -*- coding: utf-8 -*-
"""
Created on Sun Apr 11 14:46:42 2021

@author: hazem_ashraf
"""
import time
import pandas as pd
import numpy as np
import datetime
CITY_DATA = { 'chicago': 'chicago.csv','ch' :'chicago.csv',
              'new york city': 'new_york_city.csv','ny':'new_york_city.csv',
              'washington': 'washington.csv','wa':'washington.csv' }

month_data = ['january', 'february', 'march', 'april', 'may' , 'june','all']
day_data =['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday' , 'sunday','all']
def get_filters(city, month, day,time):
 while True:
    print('Hello! Let\'s explore some US bikeshare data!')
    city = input("please Write the city you want to explore: Chicago(CH), New York City(NY) or Washington(WA)? \n ").lower()
    while city not in CITY_DATA :
        print("\nsorry invalid answer ! please enter one of the following cities:\n")
        city = input("Chicago(CH), New York City(NY) or Washington(WA)? \n ").lower() 
     
    break

 while True:
    time = input("Do you want to filter by month, day, both or none? \n").lower()               
    if time == 'month':
         month = input("Which month: January, February, March, April, May , June or ALL? \n").lower()
         while month not in month_data:
            print("\nplease enter one of the following months !\n")
            month = input("Which month: January, February, March, April, May , June or ALL? \n").lower()
         
         break
    
    elif time == 'day':
         day = input("Which day: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday , Sunday or ALL ? : \n").lower()
         while day not in day_data:
              print("\nplease enter one of the following day !\n")
              day = input("Which day: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday , Sunday or ALL ? : \n").lower()
        
         break
    
    elif time == 'both':
      
        month = input("Which month: January, February, March, April, May , June or ALL? \n").lower()
        while month not in month_data   :
            print("\nsorry invalid answer! please enter one of the following months:\n")
            month = input("Which month: January, February, March, April, May , June or ALL? \n").lower()
       
        day = input("Which day: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday , Sunday or ALL ? : \n").lower()
        while  day not in day_data:
            print("\nsorry invalid answer! please enter one of the following day:\n")
            day = input("Which day: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday , Sunday or ALL ? : \n").lower()
                
        
        break
    
                
    elif time == 'none':
        break       
    else:
        print("sorry invalid answer! please choose filter from the following: \n")
        continue
 print ("\n Thanks and here is your stats \n")
 # print(city)
 # print(month)
 # print(day)
 print('-'*40)
 return city, month, day,time

def load_data(city, month, day,time):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """

    # load data file into a dataframe
    
    df = pd.read_csv(CITY_DATA[city])

    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    # extract month and day of week from Start Time to create new columns
    df['month'] = df['Start Time'].dt.month_name()
    df['day_of_week'] = df['Start Time'].dt.day_name()

 
    # filter by month if applicable
    if time == month and month != 'all' :
        # use the index of the months list to get the corresponding int
        months = ['january', 'february', 'march', 'april', 'may' , 'june']
        month = months.index(month) + 1

        # filter by month to create the new dataframe
        df = df[df['month'] == month]

    # filter by day of week if applicable
    elif time == day:
        # filter by day of week to create the new dataframe
        df = df[df['day_of_week'] == day.title()]
 
    
        
    return df

def time_stats(df,city):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel in : {} \n'.format(city))
    start_time = time.time()

    df['Start Time'] = pd.to_datetime(df['Start Time']) 

    # extract hour from the Start Time column to create an hour column
    df['hour'] = df['Start Time'].dt.hour
    
    # extract month from the Start Time column to create an month column
    df['month'] = df['Start Time'].dt.month_name()
    
    # extract day from the Start Time column to create an day column
    df['day'] = df['Start Time'].dt.day_name()
    
    # find the most popular hour
    popular_hour = df['hour'].mode()[0]
    print('Most Popular Start Hour:', popular_hour)

    # find the most popular day
    popular_day = df['day'].mode()[0]
    
    print('Most Popular day:', popular_day)   
    
    # find the most popular month
    popular_month = df['month'].mode()[0]
   
    print('Most Popular month:', popular_month)
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
def station_stats(df,city):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip in: {} \n'.format(city))
    start_time = time.time()

    # display most commonly used start station
    start_station = df['Start Station'].mode()[0]
    print('most commonly used start station:', start_station)

    # display most commonly used end station
    end_station = df['End Station'].mode()[0]
    print('most commonly used End station:', end_station)

    # display most frequent combination of start station and end station trip
    combination=(df['Start Station'] +' : '+ df['End Station']).mode()[0]
    print('most commonly used combination stations:', combination)
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)  
    
def trip_duration_stats(df,city):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration in: {} \n'.format(city))
    start_time = time.time()

    # display total travel time
     
    total_travel_time = df['Trip Duration'].sum()
    hours= total_travel_time//3600
    total_travel_time %=3600
    minutes= total_travel_time//60
    total_travel_time %=60
    seconds= total_travel_time
    print("Total Travel Time : {} hr : {} min. : {} sec.".format(hours,minutes,seconds))
    
    # display mean travel time
    mean_travel_time = df['Trip Duration'].mean()
    hours= mean_travel_time//3600
    mean_travel_time %=3600
    minutes= mean_travel_time//60
    mean_travel_time %=60
    seconds= mean_travel_time
    print("Average Travel Time : {} hr : {} min. : {} sec.".format(hours,minutes,seconds)) 
    

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
def user_stats(df,city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats in: {} \n'.format(city))
    start_time = time.time()

    # Display counts of user types
    user_types = df['User Type'].value_counts()

    print("\nUsers Types :\n",user_types)

    # Display counts of gender
    if city  =='washington' or city == 'wa' :
     print("\nsorry we dont have gender or birth year info ")
     
    else:  
     Gender = df['Gender'].value_counts()
     print("\nGender :\n",Gender)

    # Display earliest, most recent, and most common year of birth
     common_year = df['Birth Year'].mode()[0]
     print("\nmost common year of birth :\n", common_year)
     earliest_year= df['Birth Year'].min()
     print("\nearliest  year of birth :\n", earliest_year)
     most_recent= df['Birth Year'].max()
     print("\nmost recent year of birth :\n", most_recent)
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
def display_data(df):
    view_data = input('\nWould you like to view 5 rows of individual trip data? Enter yes or no\n')
    start_loc = 0
    while view_data == 'yes' :
      
      if view_data not in ['yes', 'no']:
        view_data = input("soryy invalid answer. Please type Yes or No.").lower()
      elif view_data == 'yes':
        print(df.iloc[start_loc : start_loc + 5])
        start_loc += 5
        view_data = input("Do you want to see more? Yes or No\n").lower()
        
        continue
       
def main():
    city = ""
    month = ""
    day = ""
    time=""
    while True:
        city, month, day ,time= get_filters(city, month, day,time)
        df = load_data(city, month, day,time)
        time_stats(df,city)
        station_stats(df,city)
        trip_duration_stats(df,city)
        user_stats(df,city)
        display_data(df)
        restart = input('Would you like to restart? Enter yes or no.\n').lower()
        if restart != 'yes':
            break
        
        
if __name__ == "__main__":
	main()
